//
//  ViewController.swift
//  DatePicker
//
//  Created by Rp on 11/12/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet var datePicker : UIDatePicker!
    @IBOutlet var textfield : UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        datePicker.datePickerMode = UIDatePickerMode.date
        datePicker.minimumDate = Date()
        datePicker.addTarget(self, action: #selector(dateChange(datepicker:)), for: .valueChanged)
        
        let strDate = "12/22/2020"
        let dateformater = DateFormatter()
        dateformater.dateFormat = "MM/dd/yyyy"
        let date = dateformater.date(from: strDate)
        datePicker.maximumDate = date
        
        textfield.inputView = datePicker
        
    }
    
    @objc func dateChange(datepicker:UIDatePicker){
        
        let dateformater = DateFormatter()
        dateformater.dateFormat = "MM/dd/yyyy"
        textfield.text = dateformater.string(from: datepicker.date)
        view.endEditing(true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

